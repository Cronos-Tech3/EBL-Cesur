﻿
namespace Practica_1
{
    public partial class MainWindow 
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}