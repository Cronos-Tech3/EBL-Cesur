namespace Ej4.Modelo;

public class Productos
{
    public string Name { get; set; }
    public string Price { get; set; }
    public string ImageSource { get; set; }
}