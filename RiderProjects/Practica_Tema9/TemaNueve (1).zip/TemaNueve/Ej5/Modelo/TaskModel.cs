namespace Ej5.Modelo;

public class TaskModel
{
    public string Name { get; set; }
    public bool IsCompleted { get; set; }
}