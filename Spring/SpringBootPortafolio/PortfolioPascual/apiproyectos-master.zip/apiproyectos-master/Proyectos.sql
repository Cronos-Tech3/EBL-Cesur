create database portfolio;
use portfolio;

insert into proyectos(nombre, descripcion,imagen,url)
values
("Trivial", "Juego clásico del trivial con registro de jugadores y puntuación con lado cliente y servidor", "https://play-lh.googleusercontent.com/hyYo6mHC-Qr1q-fvbG5T1fj8ZtG18lt2nL3HKIAvUDnCp_pYkUPJf7TjDtMvfPT47ug", "https://gitlab.com/Gagurum/trivialproject01.git"),
("Login", "Login de una app móvil que guarda en shared preferences los correos, nombres y contraseñas", "https://www.videojuegosydesarrollo.com/wp-content/uploads/2020/01/login-blue-tones.jpg", "https://gitlab.com/grupo3144306/login.git"),
("Pokedex", "Aplicación móvil que se conecta a una API rest para caragr una lista de Pokemon y mostrarlos como si se tratase de una poekdex", "https://user-images.githubusercontent.com/84812552/233459737-46aa426a-7c0a-439c-8ebc-b0a6ca89ba01.png", "https://gitlab.com/grupo3144306/pokedex.git"),
("APIPokemon", "API rest que contiene un listado de los 151 primeros pokemon", "https://images.wikidexcdn.net/mwuploads/wikidex/thumb/5/56/latest/20200307023245/Charmander.png/800px-Charmander.png", "https://gitlab.com/grupo3144306/apipokemon.git");

insert into lenguaje (imagen,nombre) values
("https://proximahost.es/blog/wp-content/uploads/2022/01/java.jpg", "java"),
("https://cms-assets.tutsplus.com/uploads/users/1499/posts/29820/preview_image/kotlin.jpg", "Kotlin");
select * from proyectos_lenguajes;

insert into proyectos_lenguajes values (9,1),(10,2),(11,2),(12,1);

