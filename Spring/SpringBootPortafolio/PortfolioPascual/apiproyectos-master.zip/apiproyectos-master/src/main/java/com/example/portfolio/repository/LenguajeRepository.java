package com.example.portfolio.repository;

import com.example.portfolio.model.Lenguaje;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LenguajeRepository extends JpaRepository<Lenguaje,Integer> {
}
