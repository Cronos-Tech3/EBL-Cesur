package com.example.portfolio.controller;

import com.example.portfolio.service.ProyectoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BasicController {
    @Autowired
    ProyectoService proyectoService;

    @RequestMapping("/proyectos")
    String index(Model model){
        model.addAttribute("proyectos", proyectoService.getAllProyectos());
        return "index";
    }
    @RequestMapping("/proyectos/{id}")
    String portfolio(@PathVariable Integer id, Model model){
        model.addAttribute("proyecto", proyectoService.getProyectoById(id));
        return "vistaProyecto";
    }

}
