package com.example.portfolio.controller;

import com.example.portfolio.model.Proyecto;
import com.example.portfolio.service.ProyectoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/proyectos")
public class ProyectoController {
    @Autowired
    ProyectoService proyectoService;

    public List<Proyecto> verJuegos(){
        return proyectoService.getAllProyectos();
    }
}
